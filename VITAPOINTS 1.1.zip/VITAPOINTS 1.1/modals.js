// modals.js

// Funções para o modal de login
function showLogin() {
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
        loginModal.classList.remove('hidden');
    } else {
        console.warn('Login modal not found.');
    }
}

function hideLogin() {
    const loginModal = document.getElementById('loginModal');
    if (loginModal) {
        loginModal.classList.add('hidden');
    }
}

// Funções para o modal de cadastro
function showSignup() {
    const signupModal = document.getElementById('signupModal');
    if (signupModal) {
        signupModal.classList.remove('hidden');
    } else {
        console.warn('Signup modal not found.');
    }
}

function hideSignup() {
    const signupModal = document.getElementById('signupModal');
    if (signupModal) {
        signupModal.classList.add('hidden');
    }
}

// Funções para alternar entre login e cadastro
function switchToSignup() {
    hideLogin();
    showSignup();
}

function switchToLogin() {
    hideSignup();
    showLogin();
}

// Fechar modais ao clicar fora
window.addEventListener('click', function(event) {
    const loginModal = document.getElementById('loginModal');
    const signupModal = document.getElementById('signupModal');

    if (loginModal && event.target === loginModal) {
        hideLogin();
    }
    if (signupModal && event.target === signupModal) {
        hideSignup();
    }
});

// Função para o login de administrador (mantida aqui por ser global)
function showAdminLogin() {
    alert('Você será redirecionado para a página de login do administrador!');
    // Em um sistema real, seria window.location.href = 'admin-login.html';
}

// Funções para o FAQ (acordeão) - se estiver em mais de uma página, também podem vir para cá
// Por enquanto, vou deixá-la na index.html se for a única a usá-la.
// Se outras páginas tiverem FAQ, me avise para mover.